import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore } from '@angular/fire/firestore';

@Injectable({
    providedIn: 'root'
})

export class AuthService {
    constructor(private firestore: AngularFirestore, public afAuth: AngularFireAuth,) { }

    async login(email, pass) {
        return this.afAuth.signInWithEmailAndPassword(email, pass);
    }
}